// Data Types

// null can have only null value

let a1: null;

//Error a1 = 1;

// undefined -- can only have one value undefines

let a2: undefined;

// a2 = 'a2';

// void -- setting a variable to void can only have two values null and undefined.

// Boolean, number, string -- self explanatory

// Array and tupels

let array1: String[] = ['a','b'];
// Generic type decleration
let array2: Array<number> = [1,2];

// tuples --  fix set of values of different types

let tuple1:[number, string, number, string] = [1,'Anand',2,'Sardar'];

// any and never type -- any is self explanatory and never represents a value that is never going to happen

// Union type

var val:string|number 
val = 12 
console.log("numeric value of val "+val) 
val = "This is a string" 
console.log("string value of val "+val)

function disp(name:string|string[]) { 
    if(typeof name == "string") { 
       console.log(name) 
    } else { 
       var i; 
       
       for(i = 0;i<name.length;i++) { 
          console.log(name[i])
       } 
    } 
 } 
 disp("mark") 
 console.log("Printing names array....") 
 disp(["Mark","Tom","Mary","John"])