// Generics
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
function randomElem(theArray) {
    var randomIndex = Math.floor(Math.random() * theArray.length);
    return theArray[randomIndex];
}
var colors = ['violet', 'indigo', 'blue', 'green'];
var randomColor = randomElem(colors);
var genImpl = /** @class */ (function () {
    function genImpl(variable) {
        this.variable = variable;
    }
    genImpl.prototype.printVariable = function () {
        console.log(this.variable);
    };
    return genImpl;
}());
var genex = new genImpl('genric example');
genex.printVariable();
function genFunc(params) {
    params.printVariable();
}
var genImpl2 = /** @class */ (function (_super) {
    __extends(genImpl2, _super);
    function genImpl2(variable) {
        return _super.call(this, variable) || this;
    }
    return genImpl2;
}(genImpl));
var args = new genImpl2('Gen ex');
genFunc(args);
