"use strict";
exports.__esModule = true;
var LikeButton = /** @class */ (function () {
    //private _likes: number;
    function LikeButton(_likesCount) {
        this._likesCount = _likesCount;
        this._state = false;
        //this._likes = likes
    }
    LikeButton.prototype.click = function () {
        this._state ? this._likesCount-- : this._likesCount++;
        this._state = !this._state;
    };
    Object.defineProperty(LikeButton.prototype, "state", {
        get: function () {
            return this._state;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LikeButton.prototype, "likesCount", {
        get: function () {
            return this._likesCount;
        },
        enumerable: true,
        configurable: true
    });
    return LikeButton;
}());
exports.LikeButton = LikeButton;
