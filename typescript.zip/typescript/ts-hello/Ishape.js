// class Rec implements Drawing.Ishape {
//     public draw() { 
//         console.log("Circle is drawn"); 
//      }
// }
