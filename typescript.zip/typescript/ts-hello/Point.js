"use strict";
exports.__esModule = true;
var Point = /** @class */ (function () {
    // private x: number;
    // private y: number;
    // ? to make parameter optional
    function Point(x, y) {
        this.x = x;
        this.y = y;
        // this.x = x;
        // this.y = y;
    }
    Point.prototype.draw = function () {
        console.log("drawing from " + this.x + " to " + this.y);
    };
    ;
    Point.prototype.getDistance = function () {
        console.log("distance is " + (this.y - this.x));
    };
    return Point;
}());
exports.Point = Point;
