/// <reference path = "Ishape.ts" />
var Test;
(function (Test) {
    var Circle = /** @class */ (function () {
        function Circle() {
        }
        Circle.prototype.draw = function () {
            console.log("Circle is drawn");
        };
        return Circle;
    }());
    Test.Circle = Circle;
})(Test || (Test = {}));
new Test.Circle().draw();
