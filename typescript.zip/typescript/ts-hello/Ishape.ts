namespace Drawing {
    export interface Ishape {
        draw(): void;
    }
}