import { Point } from './Point';
let point = new Point(9,3);

point.draw();