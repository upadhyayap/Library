var Dog = /** @class */ (function () {
    function Dog(name) {
        this.name = name;
    }
    Dog.prototype.speak = function () {
        return "barking";
    };
    return Dog;
}());
var dog = new Dog('puppy');
console.log(dog.speak());
var Circle = /** @class */ (function () {
    function Circle(color) {
        this.color = color;
    }
    Circle.prototype.draw = function () {
        console.log('Circle is drawn');
    };
    return Circle;
}());
var circle = {};
circle.color = 'red';
var Clock = /** @class */ (function () {
    function Clock(h, m) {
    }
    Clock.prototype.setTime = function (d) {
        this.currentTime = d;
    };
    return Clock;
}());
function getCounter() {
    var counter = function (start) { };
    counter.interval = 123;
    counter.reset = function () { };
    return counter;
}
var c = getCounter();
c(10);
c.reset();
c.interval = 5.0;
console.log(c.interval);
// Data Types
// null can have only null value
var a1;
//Error a1 = 1;
// undefined -- can only have one value undefines
var a2;
// a2 = 'a2';
// void -- setting a variable to void can only have two values null and undefined.
// Boolean, number, string -- self explanatory
// Array and tupels
var array1 = ['a', 'b'];
// Generic type decleration
var array2 = [1, 2];
// tuples --  fix set of values of different types
var tuple1 = [1, 'Anand', 2, 'Sardar'];
// any and never type -- any is self explanatory and never represents a value that is never going to happen
