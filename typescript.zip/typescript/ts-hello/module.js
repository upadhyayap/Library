"use strict";
exports.__esModule = true;
var Point_1 = require("./Point");
var point = new Point_1.Point(9, 3);
point.draw();
