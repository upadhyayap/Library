function log(msg: String) {
    console.log(msg);
}

log('javascript in Typescript');



let num: number = 1;
let bool: boolean = true;
let str: string = 'something';
let numbers: number[]  = [1,2,3];
let anything: any[] = ['any',1,true];

enum Colors {Red = 0, Green = 1, Blue = 2};

console.log(Colors.Red);
console.log(num);
console.log(str);
console.log(bool);

numbers.forEach((it) => {console.log(it)});


// Type Assertions
let message;
message='abc';

let endsWithC = (<string>message).endsWith('c');
let anotherWay = (message as string).endsWith('c');

console.log(anotherWay);

// Arrow functions
var func = (msg: String) => {console.log(msg)};

func('msg');

// Interfaces
// Inline Notations
let drawPoint = (point: {x: number, y: number}) => {
    console.log(`Drawing from ${point.x} to ${point.y}`);
}

drawPoint({x:1, y:2});

interface Point {
    x: number,
    y: number,
    draw: () => void
}

let drawPointCompact = (point: Point) => {
    console.log(`Drawing from ${point.x} to ${point.y}`);
}

class Dot {
    // private x: number;
    // private y: number;
    // ? to make parameter optional
    constructor(private x?: number, private y?: number) {
        // this.x = x;
        // this.y = y;
    }
    public draw () {
        console.log(`drawing from ${this.x} to ${this.y}`);
    };

    protected getDistance(){
        console.log(`distance is ${this.y - this.x}`);
    }

    get X(){
        return this.x;
    }

    set X(value: number) {
        if(value < 0)
            throw new Error('Value can not be less than 0');
        this.x = value;
    }
}

let dot = new Dot(4,5);
//  let dot: Dot = new Dot()
console.log(dot.X);
dot.X = 7;
console.log(dot.X);
dot.draw();




