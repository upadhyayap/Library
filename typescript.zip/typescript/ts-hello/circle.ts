/// <reference path = "Ishape.ts" />

namespace Test {
    export class Circle implements Drawing.Ishape {
        public draw() { 
            console.log("Circle is drawn"); 
         }
    }
}

new Test.Circle().draw();