interface Animal {
    name: String;
    speak(): String;
}

class Dog implements Animal {
    name: String;

    constructor(name: String) {
        this.name = name;
    }

    speak() {
        return "barking";
    }
}

let dog = new Dog('puppy');
console.log(dog.speak());

interface Shape{
    color: String;
    draw(): void;
}

class Circle implements Shape {
    color: String;

    constructor(color: String){
        this.color = color;
    }

    draw(){
        console.log('Circle is drawn');
    }
}

let circle = <Circle>{};

circle.color = 'red';
// Error
//circle.draw();

interface ClockInterface {
    currentTime: Date;
    setTime(d: Date);
}

class Clock implements ClockInterface {
    currentTime: Date;
    setTime(d: Date) {
        this.currentTime = d;
    }
    constructor(h: number, m: number) { }
}

interface Counter {
    (start: number): string;
    interval: number;
    reset(): void;
}

function getCounter(): Counter {
    let counter = <Counter>function (start: number) { };
    counter.interval = 123;
    counter.reset = function () { };
    return counter;
}

let c = getCounter();
c(10);
c.reset();
c.interval = 5.0;

console.log(c.interval);