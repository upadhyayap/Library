import { LikeButton } from "./like.";

let like = new LikeButton(0);
console.log(`initial likes ${like.likesCount} and state is ${like.state}`)
like.click();
console.log(`initial likes ${like.likesCount} and state is ${like.state}`)
like.click();
console.log(`initial likes ${like.likesCount} and state is ${like.state}`)