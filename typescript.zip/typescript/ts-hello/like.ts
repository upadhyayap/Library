import { Button } from "./Button";

export class LikeButton implements Button{
    _state: boolean = false;
    constructor(private _likesCount: number) {}

    click() {
        this._state ? this._likesCount-- : this._likesCount++
        this._state = !this._state;
    }

    // get state(): boolean {
    //     return this._state;
    // }

    // get likesCount(): number {
    //     return this._likesCount;
    // }
}

class CoursesComponent {
    constructor(public _hits: number = 0) {}

    click(): void {
        this._hits++;
    }

    // get hits(): number {
    //     return this._hits;
    // }
}

let courses = new CoursesComponent();

console.log(courses._hits);
