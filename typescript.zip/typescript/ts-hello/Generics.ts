// Generics

function randomElem<T>(theArray: T[]): T {
    let randomIndex = Math.floor(Math.random()*theArray.length);
    return theArray[randomIndex];
}
 
let colors: string[] = ['violet', 'indigo', 'blue', 'green'];
let randomColor: string = randomElem(colors);

interface  generic<T>{
    variable: T;
    printVariable(): void;
}

class genImpl<T> implements generic<T>{
    variable: T;
    constructor(variable: T) {
        this.variable = variable;
    }

    printVariable(){
        console.log(this.variable);
    }
}

let genex: genImpl<string> = new genImpl('genric example');

genex.printVariable();

function genFunc<T extends genImpl<string>>(params: T): void {
    params.printVariable();
}


class genImpl2<T> extends genImpl<T>{
    constructor(variable: T) {
        super(variable);
    }
}

let args: genImpl<string> = new genImpl2('Gen ex');

genFunc(args);
