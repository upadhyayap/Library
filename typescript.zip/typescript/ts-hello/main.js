function log(msg) {
    console.log(msg);
}
log('javascript in Typescript');
var num = 1;
var bool = true;
var str = 'something';
var numbers = [1, 2, 3];
var anything = ['any', 1, true];
var Colors;
(function (Colors) {
    Colors[Colors["Red"] = 0] = "Red";
    Colors[Colors["Green"] = 1] = "Green";
    Colors[Colors["Blue"] = 2] = "Blue";
})(Colors || (Colors = {}));
;
console.log(Colors.Red);
console.log(num);
console.log(str);
console.log(bool);
numbers.forEach(function (it) { console.log(it); });
// Type Assertions
var message;
message = 'abc';
var endsWithC = message.endsWith('c');
var anotherWay = message.endsWith('c');
console.log(anotherWay);
// Arrow functions
var func = function (msg) { console.log(msg); };
func('msg');
// Interfaces
// Inline Notations
var drawPoint = function (point) {
    console.log("Drawing from " + point.x + " to " + point.y);
};
drawPoint({ x: 1, y: 2 });
var drawPointCompact = function (point) {
    console.log("Drawing from " + point.x + " to " + point.y);
};
var Dot = /** @class */ (function () {
    // private x: number;
    // private y: number;
    // ? to make parameter optional
    function Dot(x, y) {
        this.x = x;
        this.y = y;
        // this.x = x;
        // this.y = y;
    }
    Dot.prototype.draw = function () {
        console.log("drawing from " + this.x + " to " + this.y);
    };
    ;
    Dot.prototype.getDistance = function () {
        console.log("distance is " + (this.y - this.x));
    };
    Object.defineProperty(Dot.prototype, "X", {
        get: function () {
            return this.x;
        },
        set: function (value) {
            if (value < 0)
                throw new Error('Value can not be less than 0');
            this.x = value;
        },
        enumerable: true,
        configurable: true
    });
    return Dot;
}());
var dot = new Dot(4, 5);
//  let dot: Dot = new Dot()
console.log(dot.X);
dot.X = 7;
console.log(dot.X);
dot.draw();
