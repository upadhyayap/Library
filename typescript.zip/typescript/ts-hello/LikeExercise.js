"use strict";
exports.__esModule = true;
var like_1 = require("./like.");
var like = new like_1.LikeButton(0);
console.log("initial likes " + like.likesCount + " and state is " + like.state);
like.click();
console.log("initial likes " + like.likesCount + " and state is " + like.state);
like.click();
console.log("initial likes " + like.likesCount + " and state is " + like.state);
