export interface Button {
    readonly _state: boolean;
    click: () => void;
}