"use strict";
exports.__esModule = true;
var LikeButton = /** @class */ (function () {
    function LikeButton(_likesCount) {
        this._likesCount = _likesCount;
        this._state = false;
    }
    LikeButton.prototype.click = function () {
        this._state ? this._likesCount-- : this._likesCount++;
        this._state = !this._state;
    };
    return LikeButton;
}());
exports.LikeButton = LikeButton;
var CoursesComponent = /** @class */ (function () {
    function CoursesComponent(_hits) {
        if (_hits === void 0) { _hits = 0; }
        this._hits = _hits;
    }
    CoursesComponent.prototype.click = function () {
        this._hits++;
    };
    return CoursesComponent;
}());
var courses = new CoursesComponent();
console.log(courses._hits);
