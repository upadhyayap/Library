export class Point {
    // private x: number;
    // private y: number;
    // ? to make parameter optional
    constructor(private x?: number, private y?: number) {
        // this.x = x;
        // this.y = y;
    }
    public draw () {
        console.log(`drawing from ${this.x} to ${this.y}`);
    };

    protected getDistance(){
        console.log(`distance is ${this.y - this.x}`);
    }
}

 